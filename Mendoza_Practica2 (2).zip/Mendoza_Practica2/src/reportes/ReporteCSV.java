package reportes;

import java.util.List;

public class ReporteCSV implements Reporte {
    @Override
    public void exportar(List<String> datos) {
        System.out.println("  FORMATO UTILIZADO: CSV (Documento y tabla)");
        for (String dato : datos) {
            System.out.println("[CSV] " + dato.replace("-" , ", "));
        }
    }

    @Override
    public void generarReporte(List<String> ventas) {

    }
}
