package reportes;
import java.util.List;

public interface Reporte {
        void exportar(List<String> datos);


    void generarReporte(List<String> ventas);
}

