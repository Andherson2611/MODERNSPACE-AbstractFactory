package reportes;

import java.util.List;

public class ReporteExcel implements Reporte {
    @Override
    public void exportar(List<String> datos) {
        System.out.println("  FORMATO UTILIZADO: EXCEL (Tablas)");
        for (String dato : datos) {
            System.out.println("[EXCEL] " + dato);
        }
    }
}
