package reportes;

import java.util.List;

public class ReportePDF implements Reporte {
    @Override
    public void exportar(List<String> datos) {
        System.out.println("  FORMATO UTILIZADO: PDF (Documento)");
        for (String dato : datos) {
            System.out.println("[PDF] " + dato);
        }
    }

    @Override
    public void generarReporte(List<String> ventas) {

    }
}
