package reportes;
import java.util.List;

public abstract class Reporteabs {

    public abstract Reporte crearReporte();

    public void generarReporte(List<String> datos) {
        Reporte reporte = crearReporte();
        reporte.exportar(datos);
    }
}