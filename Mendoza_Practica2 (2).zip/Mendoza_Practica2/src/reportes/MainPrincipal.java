package reportes;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class MainPrincipal {
    public static void main(String[] args) {
       //Productos de la lista
        List<String> ventas = Arrays.asList(
                "Venta 1 - Televisor - S/1570.00",
                "Venta 2 - Parlante - s/38.90",
                "Venta 3 - Audifionos - s/90.00"
        );

        Scanner scanner = new Scanner(System.in);
        System.out.println("=== SISTEMA DE EXPORTACIÓN DE REPORTES ===");
        System.out.print("Ingrese el formato de reporte a generar (pdf / excel / csv): ");
        String formato = scanner.nextLine().trim().toLowerCase();

        Reporte reporte= null;

        // Selección de la FÁBRICA correspondiente (Cumple con Factory Method)
        switch (formato) {
            case "pdf":
                reporte = new ReportePDF();
                break;
            case "excel":
                reporte = new ReporteExcel();
                break;
            case "csv":
                reporte = new ReporteCSV();
                break;
            default:
                System.out.println("Error: Formato no reconocido.");
                scanner.close();
                return;
        }

        // El cliente genera el reporte sin conocer las clases concretas (ReportePDF, etc.)
        reporte.generarReporte(ventas);

        scanner.close();
    }
}
